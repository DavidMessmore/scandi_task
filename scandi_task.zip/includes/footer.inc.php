<footer>
<br>
<br>
<br>
<hr>
<p>Scandiweb Test assignment</p>
</footer>